import { type NativeProps } from './PdfAnnotationViewNativeComponent';
import React, { type ReactElement } from 'react';
import { type StyleProp, type ViewStyle, type ScrollViewProps } from 'react-native';
export * from './PdfAnnotationViewNativeComponent';
export interface Handle {
    saveAnnotations: (file: string) => void;
    loadAnnotations: (file: string) => void;
    undo: () => void;
    redo: () => void;
    clear: () => void;
    setPage: (page: number) => void;
}
export interface Props extends Omit<NativeProps, 'onPageCount' | 'onPageChange' | 'onDocumentFinished'> {
    onPageChange?: (currentPage: number) => unknown;
    onPageCount?: (pageCount: number) => unknown;
    renderPageIndicatorItem?: (props: PageIndicatorProps) => ReactElement;
    currentPage?: number;
    containerStyles?: StyleProp<ViewStyle>;
    hidePagination?: boolean;
    pageIndicatorContainerStyles?: StyleProp<ViewStyle>;
    onDocumentFinished?: (direction: 'next' | 'previous') => unknown;
    scrollViewComponent?: (props: ScrollViewProps) => ReactElement;
}
export interface PageIndicatorProps {
    onClick: () => unknown;
    active: boolean;
    index: number;
}
export declare const PageIndicator: ({ onClick, active }: PageIndicatorProps) => import("react/jsx-runtime").JSX.Element;
export declare const PdfAnnotationView: React.ForwardRefExoticComponent<Props & React.RefAttributes<Handle>>;
//# sourceMappingURL=index.d.ts.map